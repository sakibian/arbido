(() => {
var exports = {};
exports.id = 931;
exports.ids = [931];
exports.modules = {

/***/ 8038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 8704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 7897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 6786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 1090:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param.js");

/***/ }),

/***/ 8652:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes.js");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 9274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1668:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 9099:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "GlobalError": () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "StaticGenerationSearchParamsBailoutProvider": () => (/* reexport default from dynamic */ next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "actionAsyncStorage": () => (/* reexport safe */ next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__.actionAsyncStorage),
/* harmony export */   "createSearchParamsBailoutProxy": () => (/* reexport safe */ next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__.createSearchParamsBailoutProxy),
/* harmony export */   "decodeAction": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeAction),
/* harmony export */   "decodeReply": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeReply),
/* harmony export */   "originalPathname": () => (/* binding */ originalPathname),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "preconnect": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preconnect),
/* harmony export */   "preloadFont": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadFont),
/* harmony export */   "preloadStyle": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadStyle),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   "staticGenerationBailout": () => (/* reexport safe */ next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__.staticGenerationBailout),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8829);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5226);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2872);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8412);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1839);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8214);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7797);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9282);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3785);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5183);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5815);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6370);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(515);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__);

    const tree = {
        children: [
        '',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 8080)), "/home/rokibulslam/Working Directory/arbido/arbido/app/page.js"],
          
        }]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 2335)), "/home/rokibulslam/Working Directory/arbido/arbido/app/layout.js"],
          
        }
      ]
      }.children;
    const pages = ["/home/rokibulslam/Working Directory/arbido/arbido/app/page.js"];

    
    
    
    

    

    
    

    
    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
    

    const originalPathname = "/page"
  

/***/ }),

/***/ 1922:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 9222, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 8301, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 3751, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 4765, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 5192, 23))

/***/ }),

/***/ 505:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 408, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 53, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7053));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 4005));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 888));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 1261));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 2390));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3610));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3899));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7090));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 9856));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 94));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 8859));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 2447));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 5869));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 5167));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3518));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 1678));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 4787));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 2101));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3303));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 726));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 4545));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 1086));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3637))

/***/ }),

/***/ 6499:
/***/ (() => {



/***/ }),

/***/ 4787:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Contact_Contact)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(8038);
;// CONCATENATED MODULE: ./components/Navbar/Button.jsx


const Button = ({ children , props  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("button", {
        className: "h-14 w-52 bg-black text-white tracking-[5px]",
        children: children
    });
};
/* harmony default export */ const Navbar_Button = (Button);

// EXTERNAL MODULE: ./node_modules/react-hook-form/dist/index.esm.mjs
var index_esm = __webpack_require__(1031);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(8421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./public/assets/images/contact/contact01.png
/* harmony default export */ const contact01 = ({"src":"/_next/static/media/contact01.7c45b3fe.png","height":1080,"width":1080,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAATlBMVEX////0+vOf4J9p4nS357mg9KJoz3f5/vrs/uzm+ejd99+M3pXH98lg2Wgt3kC5/LiR7Zlb02qG15I7z0sFuiJHwFVT1lfp8emt7bLX8tyty9uaAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAPklEQVR4nB3GRxKAMAwAsSXNOD10/v9RJugkQBYmIZm/Eq3NzijkUvdabtSN47w66OZbS+Elhu79Exyi6yQfPvgCI+/zxTYAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
// EXTERNAL MODULE: ./node_modules/react-hot-toast/dist/index.mjs + 1 modules
var dist = __webpack_require__(3518);
;// CONCATENATED MODULE: ./components/Contact/Contact.jsx
/* __next_internal_client_entry_do_not_use__ default auto */ 






const Contact = ()=>{
    const { register , handleSubmit , reset , formState: { errors  }  } = (0,index_esm/* useForm */.cI)();
    const onSubmit = (data)=>{
        console.log(data);
        dist.toast.success("Thank you for contacting with us!");
        reset();
    };
    console.log(errors);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "md:flex w-full items-center my-10 md:px-4",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                src: contact01,
                alt: "contact now",
                className: "hidden md:block w-1/2 py-10 px-10"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "w-full md:w-1/2 py-10 px-5 md:px-10 shadow-lg bg-lime-50",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "text-center mb-10",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: "font-bold text-3xl text-gray-900",
                                children: "Contact Now"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Enter your information to connect"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                        onSubmit: handleSubmit(onSubmit),
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex -mx-3 flex-col md:flex-row",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "w-full md:w-1/2 px-3 mb-5",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                for: "",
                                                className: "text-xs font-semibold px-1",
                                                children: "First name"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "flex",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "w-10 z-10 pl-1 text-center pointer-events-none flex items-center justify-center",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            className: "mdi mdi-account-outline text-gray-400 text-lg"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                        type: "text",
                                                        required: true,
                                                        className: "w-full -ml-10 pl-10 pr-3 py-2 rounded-lg border-2 border-gray-200 outline-none focus:border-green-500",
                                                        placeholder: "John",
                                                        ...register("firstName", {
                                                            required: true,
                                                            max: 16,
                                                            maxLength: 80
                                                        })
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "w-full md:w-1/2 px-3 mb-5",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                for: "",
                                                className: "text-xs font-semibold px-1",
                                                children: "Last name"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "flex",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "w-10 z-10 pl-1 text-center pointer-events-none flex items-center justify-center",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            className: "mdi mdi-account-outline text-gray-400 text-lg"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                        type: "text",
                                                        required: true,
                                                        className: "w-full -ml-10 pl-10 pr-3 py-2 rounded-lg border-2 border-gray-200 outline-none focus:border-green-500",
                                                        placeholder: "Smith",
                                                        ...register("lastName", {
                                                            required: true,
                                                            max: 16,
                                                            maxLength: 80
                                                        })
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "flex -mx-3",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "w-full px-3 mb-5",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                            for: "",
                                            className: "text-xs font-semibold px-1",
                                            children: "Email"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "w-10 z-10 pl-1 text-center pointer-events-none flex items-center justify-center",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "mdi mdi-email-outline text-gray-400 text-lg"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                    type: "email",
                                                    required: true,
                                                    className: "w-full -ml-10 pl-10 pr-3 py-2 rounded-lg border-2 border-gray-200 outline-none focus:border-green-500",
                                                    placeholder: "johnsmith@example.com",
                                                    ...register("email", {
                                                        required: true
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "flex -mx-3",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "w-full px-3 mb-12",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                            for: "",
                                            className: "text-xs font-semibold px-1",
                                            children: "Message"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "w-10 z-10 pl-1 text-center pointer-events-none flex items-center justify-center",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "mdi mdi-lock-outline text-gray-400 text-lg"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("textarea", {
                                                    className: "w-full -ml-10 pl-10 pr-3 py-2 rounded-lg border-2 border-gray-200 outline-none focus:border-green-500",
                                                    ...register("message", {
                                                        required: false
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full px-3 mb-5 flex justify-center",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(Navbar_Button, {
                                    className: "mx-auto",
                                    children: "Contact"
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const Contact_Contact = (Contact);


/***/ }),

/***/ 3303:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_icons_ci__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9859);
/* harmony import */ var react_icons_rx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2175);
/* __next_internal_client_entry_do_not_use__ default auto */ 



const Navbar = ()=>{
    const [showMobileMenu, setShowMobileMenu] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: `w-full xl:grid xl:place-items-center`,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("nav", {
            className: "  lg:flex lg:items-center xl:container",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                            className: "m-4 text-2xl font-bold",
                            href: "#home",
                            children: "Arbido"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            className: "px-4 my-2 mx-4 ml-auto   lg:hidden",
                            onClick: ()=>setShowMobileMenu(!showMobileMenu),
                            children: showMobileMenu ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_rx__WEBPACK_IMPORTED_MODULE_2__/* .RxCross1 */ .ySC, {
                                className: "h-8 w-8 "
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ci__WEBPACK_IMPORTED_MODULE_3__/* .CiMenuFries */ .F3G, {
                                className: "h-8 w-8 "
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                    className: (showMobileMenu ? "" : "hidden") + ` lg:ml-auto lg:items-center lg:flex bg-[#FFC700] absolute lg:relative justify-end min-h-full w-full lg:bg-white`,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            className: "py-2 grid place-items-center lg:mx-2 ",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                href: "/services",
                                className: "p-2 w-1/2 lg:w-28 text-center rounded font-bold",
                                children: "Services"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            className: "py-2 grid place-items-center lg:mx-2",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                href: "/about",
                                className: "p-2 w-1/2 lg:w-28 text-center rounded font-bold",
                                children: "About"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            className: "py-2 grid place-items-center lg:mx-2",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                href: "/blog",
                                className: "p-2 w-1/2 lg:w-28 text-center rounded font-bold",
                                children: "Blog"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            className: "py-2 grid place-items-center lg:mx-2",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                href: "/contact",
                                className: "p-2 w-1/2 lg:w-28 text-center rounded font-bold",
                                children: "Contact"
                            })
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Navbar);


/***/ }),

/***/ 2335:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "metadata": () => (/* binding */ metadata)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6495);
/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_1__);


const metadata = {
    title: "Arbido",
    description: "Web Development | Software Development | App Development | Digital Marketing Agency"
};
const RootLayout = ({ children  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("html", {
        lang: "en",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("body", {
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("main", {
                children: children
            })
        })
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RootLayout);


/***/ }),

/***/ 8080:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/react.shared-subset.js
var react_shared_subset = __webpack_require__(4212);
;// CONCATENATED MODULE: ./public/assets/icons/our-people/team01.png
/* harmony default export */ const team01 = ({"src":"/_next/static/media/team01.9346f4b5.png","height":900,"width":900,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAATlBMVEX///+d6J/O7cWH6Ik/wmJG8m+85Lj6/vzx//U4+Wre/+ac/bjk/uq+/s6t2I9h/4WD8ZAc41XO6clR2XtTzGGb4YoZ/l1p24YpzlOU/a/yqibKAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAPklEQVR4nD3GWw6AIAwEwAVaugXfCur9L2qMifM1wI8Ehzc5xFwMYJqWEDfDOLt6SwV1lePSfoO7nKJeYR88NIEB4xgrgngAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(2208);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./components/Navbar/Button.jsx


const Button = ({ children , props  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("button", {
        className: "h-14 w-52 bg-black text-white tracking-[5px]",
        children: children
    });
};
/* harmony default export */ const Navbar_Button = (Button);

;// CONCATENATED MODULE: ./components/About/About.jsx





const About = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "my-10 md:mx-4",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        className: "text-3xl mt-20 mb-3 md:text-5xl font-extrabold text-center md:text-left",
                        children: "About Us"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "border-b-8 border-[#FFC700] mx-auto md:m-0 w-36 md:w-44 mt-4 mb-8"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-col-reverse md:flex-row justify-center items-center",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-full md:w-1/2",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: team01,
                            alt: "about us",
                            className: "mx-auto p-10"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "w-full md:w-1/2",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                                className: "text-3xl md:text-4xl font-extrabold text-center md:text-left",
                                children: [
                                    "The thing about us is,",
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "text-[#FFC700]",
                                        children: "we think big"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "my-7 p-2 md:p-0",
                                children: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Praesentium ipsa iure nisi labore quo velit ex dicta atque? Rem itaque culpa, id quas neque nemo odit laboriosam voluptatem molestias eaque explicabo cum eos maxime assumenda aliquam quisquam obcaecati tenetur consequuntur."
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "flex justify-center md:justify-start",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(Navbar_Button, {
                                    children: "Contact Now"
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const About_About = (About);

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(2585);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./public/assets/images/blog/blogPhoto.png
/* harmony default export */ const blogPhoto = ({"src":"/_next/static/media/blogPhoto.5a1bca16.png","height":422,"width":638,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAMAAABPT11nAAAASFBMVEVidYlESFCkkoVaY3GSiIJygJA4PUhWaoOtpqGTgXCvm4pcSkBxaWWajohVZHl/jZzPsp1hb3yanaTet5nKwrtoZmSNnq3/685iehG6AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAMUlEQVR4nAXBBwIAEAwEsKNoa2///6kErlh3cgrQ+FbqkSCiVnauwCAzfWDAX3Az/AEjDwFyunZwegAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./public/assets/icons/readMore.png
/* harmony default export */ const readMore = ({"src":"/_next/static/media/readMore.ea257637.png","height":27,"width":45,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAMAAABPT11nAAAAFVBMVEVMaXH/xgD/zAD/xwD/xwD/xwD/xwCO5DOOAAAAB3RSTlMAUgpcLjfA5vnicQAAAAlwSFlzAAALEwAACxMBAJqcGAAAAB9JREFUeJxjYEAFLCwMjMyMjIyMzGwMTCDAwMoIlwUAA1UAKiWrPmMAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./public/assets/images/blog/blog1.png
/* harmony default export */ const blog1 = ({"src":"/_next/static/media/blog1.a5b33e1b.png","height":163,"width":163,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAe1BMVEWKj46qs7Tc0s5PTky3e2BoZ2Pbk3HEmH4jHBZ9fX7Qz9HUuao3Jx7Dg2eDUTx5WEmjc1uNX06SiYODioagpaLcycTjxLONeGlHRUObkYrRx8G0l4fT09XEtLHXqo6ne2bx3c64cEmTWD5KMCWVXkmEWkyvakpjUU3CrqDN6MyKAAAACXBIWXMAAAsTAAALEwEAmpwYAAAARklEQVR4nAXBhQGAMAADsA7mPtzd/r+QBI7zFhUBrKcsZ2UBacc+71QGGcRMoGvIeKyTNg1O/+wxCAP33pSmZcCnVLrElv13qQPqVyQXSAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/images/blog/blog2.bmp
/* harmony default export */ const blog2 = ({"src":"/_next/static/media/blog2.0789b7b6.bmp","height":326,"width":326,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./public/assets/images/blog/blog3.png
/* harmony default export */ const blog3 = ({"src":"/_next/static/media/blog3.bd92da97.png","height":163,"width":163,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAb1BMVEUGBgd3alne5Oawrq5kSSRqTy1eSTxpWVF4fH2UjIVWQy0xNDbT2N67wsbM0dWjoZ58bWmnp6hMOzCGgXyqnJRtb2+VkoZOMB4hEQdcVFVLUFw2KCOMd25rUzBfZGeLhYN0YFkjJCXJsazJx8Dv7vCMAQoTAAAACXBIWXMAAAsTAAALEwEAmpwYAAAARklEQVR4nAXBBQKAIAAEsEO6RNJu//9GNzhdZOJcwKuazM4YWsitCUPwfk/JRC6wg7xo52fcMZ6D3kbUvu/COgGHUtRZ4AeHLgO93lTqXQAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/images/blog/blog4.png
/* harmony default export */ const blog4 = ({"src":"/_next/static/media/blog4.b6aaae89.png","height":163,"width":163,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAflBMVEWSZGmldHxpaGV5jYbHnKZvenqWgIihi5KchYBXQEN5WF1KXlyoWWKFd3x3Y2ZrSk+umY+COkXNlp6qqquNbHSHZ3qtmZ3GkJCIZWd9aWmaVGJZTkvWsrePdG7VoZZObmudjo6If4ahdmyzfXfAtrGVdnmRWF6PcYeRenKJTFpeXIgYAAAACXBIWXMAAAsTAAALEwEAmpwYAAAASElEQVR4nAXBBQKAIAAEsEMalLC78/8fdENRCjYSALnkImsHjYrJhK+bg6oNpfIMaNAt9goKaZ9YH6MGmQ9zp15j2tXzvZn7AX0lBA+HNY9rAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./components/Blog/Blog.js










const Blog = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "xl:w-[1113px] xl:h-[856px] xl:my-[60px] my-[25px] xl:mx-auto mx-[10px]",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h1", {
                className: "2xl:mb-[69px] xl:mb-[59px] mb-[10px] 2xl:text-[48px] xl:text-[41px] text-[28px] font-bold font-source",
                children: [
                    "From our ",
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "text-primary-yellow",
                        children: "blog"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex 2xl:flex-row xl:flex-row flex-col 2xl:gap-[27px] xl:gap-[23px] gap-[20px]",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "xl:basis-[57%]",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full 2xl:mb-[28px] xl:mb-[24px] mb-[12px]",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: blogPhoto,
                                    alt: "Blog Photo"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "2xl:text-[12px] xl:text-[10px] text-[10px] text-[#AEB7C1] 2xl:mb-[16px] xl:mb-[13px] mb-[8px] font-extrabold uppercase",
                                children: "Website design | Thursday, 26 March 2020"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                className: "2xl:text-[34px] xl:text-[29px] text-[25px] font-source2 2xl:mb-[26px] xl:mb-[22px] mb-[10px] font-extrabold 2xl:leading-[51px] xl:leading-[44px] leading-7",
                                children: "I think night-time is dark so you can imagine with less distraction"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                className: "2xl:text-[15px] xl:text-[14px] font-sintony text-[#222A41] 2xl:leading-[24px] xl:leading-[22px] xl:mb-[46px] mb-[10px]",
                                children: "The engine that gives its mysterious inner life to a work of art must be the subterranean expression of a wish, working its way to the surface of a narrative. change is an easy panacea. it takes character to stay in one…"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                href: "#",
                                className: "flex justify-end items-center 2xl:gap-[24px] xl:gap-[22px] gap-[10px]",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "font-source font-bold text-[#FFC700] uppercase 2xl:text-[13px] xl:text-[12px] text-[11px]",
                                        children: "Read more"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "2xl:w-[44px] 2xl:h-[27px] xl:w-[38px] xl:h-[23px] w-[25px] h-[15px]",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: readMore,
                                            alt: "Read More"
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "basis-[36%] flex flex-col 2xl:gap-[27px] xl:gap-[23px] gap-[20px]",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: " flex 2xl:flex-row xl:flex-row flex-col 2xl:gap-[27px] xl:gap-[23px] gap-3",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        className: "xl:w-[163px]",
                                        src: blog1,
                                        alt: "First Blog Small Photo"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "uppercase font-extrabold text-xs 2xl:text-[12px] xl:text-[10px] text-[#AEB7C1] 2xl:mb-[20px] xl:mb-[16px] mb-[6px]",
                                                children: "website development"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "#",
                                                className: "text-black text-sm font-source font-extrabold 2xl:text-[24px] xl:text-[20px] text-[24px] 2xl:leading-[32px] xl:leading-[27px] leading-8",
                                                children: "The individual is born of nature, but the artist is born of that individual"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex 2xl:flex-row xl:flex-row flex-col 2xl:gap-[27px] xl:gap-[23px] gap-3",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        className: "w-[163px]",
                                        src: blog2,
                                        alt: "First Blog Small Photo"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "uppercase font-extrabold text-xs 2xl:text-[12px] xl:text-[10px] text-[#AEB7C1] 2xl:mb-[20px] xl:mb-[16px] mb-[6px]",
                                                children: "Brand Design"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "#",
                                                className: "text-black text-sm font-source font-extrabold 2xl:text-[24px] xl:text-[20px] text-[24px] 2xl:leading-[32px] xl:leading-[27px] leading-8",
                                                children: "A life without it is like a sunless garden when the flowers are dead"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex 2xl:flex-row xl:flex-row flex-col 2xl:gap-[27px] xl:gap-[23px] gap-3",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        className: "xl:w-[163px]",
                                        src: blog3,
                                        alt: "First Blog Small Photo"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "uppercase font-extrabold text-xs 2xl:text-[12px] xl:text-[10px] text-[#AEB7C1] 2xl:mb-[20px] xl:mb-[16px] mb-[6px]",
                                                children: "UI UX Design"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "#",
                                                className: "text-black text-sm font-source font-extrabold 2xl:text-[24px] xl:text-[20px] text-[24px] 2xl:leading-[32px] xl:leading-[27px] leading-8",
                                                children: "All sorrows can be borne if they can be put into a story"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex 2xl:flex-row xl:flex-row flex-col 2xl:gap-[27px] xl:gap-[23px] gap-3",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        className: "xl:w-[163px]",
                                        src: blog4,
                                        alt: "First Blog Small Photo"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "uppercase font-extrabold text-xs 2xl:text-[12px] xl:text-[10px] text-[#AEB7C1] 2xl:mb-[20px] xl:mb-[16px] mb-[6px]",
                                                children: "Brand Design"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "#",
                                                className: "text-black text-sm font-source font-extrabold 2xl:text-[24px] xl:text-[20px] text-[24px] 2xl:leading-[32px] xl:leading-[27px] leading-8",
                                                children: "Love is friendship set on fire. certain thoughts are prayers"
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const Blog_Blog = (Blog);

// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(5985);
;// CONCATENATED MODULE: ./components/Contact/Contact.jsx

const proxy = (0,module_proxy.createProxy)(String.raw`/home/rokibulslam/Working Directory/arbido/arbido/components/Contact/Contact.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const Contact = (__default__);
// EXTERNAL MODULE: ./node_modules/react-icons/bs/index.esm.js
var index_esm = __webpack_require__(5147);
;// CONCATENATED MODULE: ./components/Footer/Footer.jsx



const Footer = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "grid grid-cols-1 md:grid-cols-3 justify-items-start md:justify-items-center bg-[#01E81F]",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "p-9",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                        className: "text-3xl font-bold",
                        children: "Arbido"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "my-4",
                        children: "Funding freemium long tail hypotheses first mover advantage assets ownership niche market startup investor."
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        className: "flex gap-3 items-center mb-2",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* BsFillEnvelopeFill */.dcn, {}),
                            " contact@arbido.com"
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        className: "flex gap-3 items-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* BsFillTelephoneForwardFill */.vhv, {}),
                            " +880 1733 323 378"
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: " p-9",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                        className: "mb-4 text-3xl font-bold",
                        children: "Services"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-col gap-3",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: "#",
                                children: "Software Development"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: "#",
                                children: "App Development"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: "#",
                                children: "Web Development"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: "#",
                                children: "Digital Marketing"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "p-9",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                        className: "mb-4 text-3xl font-bold",
                        children: "Address"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("address", {
                        children: "123 Lorem Ipsum Street Jakarta, Indonesia"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex gap-4 mt-4",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: "#",
                                className: "",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* BsLinkedin */.NQh, {
                                    className: "text-3xl"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: "#",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* BsFacebook */.k1O, {
                                    className: "text-3xl"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: "#",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* BsTwitter */.meP, {
                                    className: "text-3xl"
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const Footer_Footer = (Footer);

;// CONCATENATED MODULE: ./assests/images/hero-01.jpg
/* harmony default export */ const hero_01 = ({"src":"/_next/static/media/hero-01.ec71d342.jpg","height":427,"width":640,"blurDataURL":"data:image/jpeg;base64,/9j/2wBDAAoHBwgHBgoICAgLCgoLDhgQDg0NDh0VFhEYIx8lJCIfIiEmKzcvJik0KSEiMEExNDk7Pj4+JS5ESUM8SDc9Pjv/2wBDAQoLCw4NDhwQEBw7KCIoOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozv/wAARCAAFAAgDASIAAhEBAxEB/8QAFQABAQAAAAAAAAAAAAAAAAAAAAb/xAAbEAACAwEBAQAAAAAAAAAAAAABAgADBBEFIf/EABQBAQAAAAAAAAAAAAAAAAAAAAH/xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIRAxEAPwCkbHR4u+q3JUvdLBbC5YkgDg+kxEQL/9k=","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./components/Navbar/Hero.jsx





const Hero = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col lg:flex-row w-full",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "bg-[#FFC700] flex flex-col p-2 text-center justify-center items-center h-[650px] w-full lg:w-1/2",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                        className: "text-[42px] lg:text-[60px] font-bold mb-8",
                        style: {
                            fontWeight: "900"
                        },
                        children: [
                            "Grow Your Brand",
                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                            "Through Digital"
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-base mb-4 text-center w-3/4",
                        children: "If the path is beautiful, let us not ask where it leads. my religion is very simple. my religion is kindness. each of us has within our power the ability to disrupt"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Navbar_Button, {
                        children: "Learn More"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "w-full lg:w-1/2 relative h-[450px] md:h-[550px] lg:h-[650px]",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "aspect-w-2 aspect-h-1",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: hero_01,
                            fill: true,
                            style: {
                                objectFit: "cover",
                                position: "absolute"
                            },
                            alt: "hero image"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "absolute inset-0 bg-gradient-to-tr from-yellow-400 to-black opacity-50"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const Navbar_Hero = (Hero);

;// CONCATENATED MODULE: ./components/Navbar/Navbar.jsx

const Navbar_proxy = (0,module_proxy.createProxy)(String.raw`/home/rokibulslam/Working Directory/arbido/arbido/components/Navbar/Navbar.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: Navbar_esModule, $$typeof: Navbar_$$typeof } = Navbar_proxy;
const Navbar_default_ = Navbar_proxy.default;


/* harmony default export */ const Navbar = (Navbar_default_);
;// CONCATENATED MODULE: ./public/assets/images/our-people/photo1.png
/* harmony default export */ const photo1 = ({"src":"/_next/static/media/photo1.e60c9991.png","height":220,"width":163,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAICAMAAADtGH4KAAAARVBMVEUOChBEJzJXQFMTFCUhHC44Kj8oGh0mJTwaERUQDxd1TlBTMT1DMzwwLkxYKScdFR4uKTNdPTxmSVtFICZeTV12O0CcV1XGuwweAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAN0lEQVR4nAXBBwLAIAgAsQNRwNHd/v+pTbDlJZOlKlZ4dI7qXF+v1bjfIX4gs7V0zt4ydgiI7QcrzQGTK8NWtAAAAABJRU5ErkJggg==","blurWidth":6,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/images/our-people/photo2.png
/* harmony default export */ const photo2 = ({"src":"/_next/static/media/photo2.070ac0cc.png","height":220,"width":163,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAICAMAAADtGH4KAAAAKlBMVEXz8fDj5ub29vb5+/3n7O/s8fTR0dHk2tLx9vje3d3Hw8K7urmlko3Ow74zxIuuAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAL0lEQVR4nDXByQHAIBADsbH3gkD6bzevSPCzMVgKU346TO57YqF5tQrNzkqmW6kPDpUAtRYEgkgAAAAASUVORK5CYII=","blurWidth":6,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/images/our-people/photo3.png
/* harmony default export */ const photo3 = ({"src":"/_next/static/media/photo3.5bbebfb0.png","height":421,"width":163,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAMAAAAICAMAAAALMbVOAAAAIVBMVEUDDA4ZHx8mMDI7PDoaIyVqbW5PT001TUsUFxeZnpvGyMcMEQFOAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAI0lEQVR4nAXBAQIAMAQDsVNl5v8PlvDf0ioS0y4mAgmUg+EABzcAXZiZTRAAAAAASUVORK5CYII=","blurWidth":3,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/images/our-people/photo4.png
/* harmony default export */ const photo4 = ({"src":"/_next/static/media/photo4.8be2d136.png","height":220,"width":163,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAICAMAAADtGH4KAAAAP1BMVEUpPRxGZTh4jG4/UzFZcz5hdUZUYj4nJB8vTSEmMhvZ2OIxWR4uXRWKmobJztGao5qjrZ6TnXm6vsG3vbmHlWWn6EkDAAAACXBIWXMAAAsTAAALEwEAmpwYAAAANUlEQVR4nAXBiQHAIAgEwVWBA/OYr/9aM0N8ISW3DzLx6w0Sf+axb1ifZwOz1bNoQwWUJOoHKqEBX+H0e24AAAAASUVORK5CYII=","blurWidth":6,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/icons/our-people/facebook.png
/* harmony default export */ const facebook = ({"src":"/_next/static/media/facebook.6dcf26f1.png","height":14,"width":8,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAICAMAAAAGL8UJAAAAIVBMVEX/xAD/xQD/yQBMaXH/xgD/xwD/wwD/xQD+xgD/vwD/1wCAJwauAAAACnRSTlMyrv0AgO9FoNEECWaTdgAAAAlwSFlzAAALEwAACxMBAJqcGAAAAClJREFUeJxjYGbhYmdgYGbkYmBm4GBlYmVhYGViYmJh4GTkYmOGiiORAA/wAKHLb0OFAAAAAElFTkSuQmCC","blurWidth":5,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/icons/our-people/instagram.png
/* harmony default export */ const instagram = ({"src":"/_next/static/media/instagram.b728611b.png","height":14,"width":14,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAG1BMVEUAAAAAAAAAAAAAAABMaXEAAAAAAAAAAAAAAABetuXRAAAACXRSTlOzqBw1AAlijCr1OrUxAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAMElEQVR4nDWLyQ0AMAyDsJM03X/iqtcPCSBAgoBI12xBDtQWMlX6gK9iJCd27untCxS5AIs3xmDvAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/icons/our-people/linkedin.png
/* harmony default export */ const linkedin = ({"src":"/_next/static/media/linkedin.87133157.png","height":13,"width":13,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAJ1BMVEUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADdEvm1AAAADXRSTlP/wNb1cquHzWDrJDZPkE8SeAAAAAlwSFlzAAALEwAACxMBAJqcGAAAADZJREFUeJw1y0kOADEIxEBDE8j2//dGjDQ+1cU4XwZjNNRQOQsi79kmmHFsJo1tkYJyW+Xi3x8a8QDLVPa3cAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/icons/our-people/left.png
/* harmony default export */ const left = ({"src":"/_next/static/media/left.bdce4707.png","height":29,"width":30,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAADFBMVEVMaXEAAAAAAAAAAAAykov8AAAABHRSTlMAFgsmmsHlbgAAAAlwSFlzAAALEwAACxMBAJqcGAAAABxJREFUeJxjYMAEjFCamZEJDBiYGSGAgQkmhQEABJQAH+CeLJcAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/icons/our-people/right.png
/* harmony default export */ const right = ({"src":"/_next/static/media/right.3ee3f47a.png","height":29,"width":30,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAGFBMVEVMaXH/xgD/xwD/xgD/wwD/yAD/xwD/yQCiOmDvAAAACHRSTlMAcTxpGTWpzY/D3RcAAAAJcEhZcwAACxMAAAsTAQCanBgAAAAjSURBVHicY2DAAZhZGJhAgJWRjYERBJgZ2aFSjKxQBgtCPQAHdwA4uQrdqQAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./components/Our People/OurPeople.js













const OurPeople = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "xl:w-[1113px] xl:h-[603px] xl:my-[60px] my-[15px] xl:mx-auto mx-[10px]",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h1", {
                className: "grid justify-items-end xl:px-[50px] 2xl:mb-[69px] xl:mb-[59px] mb-[10px] 2xl:text-[48px] xl:text-[41px] text-[28px] font-bold font-source",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "text-primary-yellow",
                                children: "People "
                            }),
                            "behind the"
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: " scenes"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "xl:grid xl:grid-cols-6 xl:gap-[25px] xl:px-4",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "xl:col-span-2 ",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                className: "2xl:text-[28px] xl:text-[27px] text-[18px] font-source2 2xl:mb-[20px] xl:mb-[18px] mb-[10px] font-extrabold 2xl:leading-[51px] xl:leading-[44px] leading-6",
                                children: "Tiara Lyodra"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                className: "2xl:text-[15px] xl:text-[14px] font-sintony font-semibold uppercase text-[#222A41] xl:mb-[18px] mb-[12px]",
                                children: "Head of Product"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex xl:gap-[18px] gap-2 xl:mb-[50px] mb-[30px]",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "#",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: facebook,
                                            alt: "Facebook"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "#",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: instagram,
                                            alt: "Instagram"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "#",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: linkedin,
                                            alt: "Linkedin"
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h5", {
                                className: "2xl:text-[15px] xl:text-[14px] font-sintony text-[#222A41] 2xl:leading-[24px] xl:leading-[22px] xl:mb-[52px] mb-[10px]",
                                children: [
                                    "Saturday found him for the first time strolling alone through zurich, breathing in the heady smell of his freedom. new adventures hid around each corner.",
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    "The future was again a secret. now, what was tiring had disappeared and only the beauty remained."
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex justify-end items-center 2xl:gap-[20px] xl:gap-[18px] gap-[5px]",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "#",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: left,
                                            alt: ""
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "#",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: right,
                                            alt: ""
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "xl:col-span-4 xl:block 2xl:block hidden",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "xl:flex xl:justify-around xl:pr-3",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    className: "xl:col-span-1 xl:place-self-end",
                                    src: photo1,
                                    alt: ""
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    className: "xl:col-span-1 xl:place-self-end",
                                    src: photo2,
                                    alt: ""
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    className: "xl:col-span-1",
                                    src: photo3,
                                    alt: ""
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    className: "xl:col-span-1 xl:place-self-end",
                                    src: photo4,
                                    alt: ""
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const Our_People_OurPeople = (OurPeople);

;// CONCATENATED MODULE: ./public/assets/images/Portfolio/portfolio-01.png
/* harmony default export */ const portfolio_01 = ({"src":"/_next/static/media/portfolio-01.4bae9d3f.png","height":980,"width":943,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAJ1BMVEX19PPx7+zq3tTu6eTr5N35+fndz8Xl08nEsaW/lYLYvrO5no2dZ1Ziq8ZSAAAACXBIWXMAAA7DAAAOwwHHb6hkAAAANklEQVR4nB3HQRKAQAjEwMyAwKr/f6+FOXUAhSRBBLDIjEz9k/bi2oCqdtjBnPd0VTPP3Lb9ARRIANU/l6drAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/images/Portfolio/porfolio02.png
/* harmony default export */ const porfolio02 = ({"src":"/_next/static/media/porfolio02.afe141af.png","height":1281,"width":2342,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAMAAACEE47CAAAAJFBMVEXu7Oro4N/i2tjz6+jSzMj9+PTp5uS3rbPfxLihjp3ey8SXlaRp95bEAAAACXBIWXMAAA7DAAAOwwHHb6hkAAAAJklEQVR4nAXBiQEAMAgCsQO09tl/3yZ4AehSpY6yKKflM2wT9OYDBukAcB+4x6sAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":4});
;// CONCATENATED MODULE: ./public/assets/images/Portfolio/porfolio03.png
/* harmony default export */ const porfolio03 = ({"src":"/_next/static/media/porfolio03.88d18863.png","height":1595,"width":3177,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAMAAACEE47CAAAABlBMVEX19vn6+/wnMr3yAAAACXBIWXMAAA7DAAAOwwHHb6hkAAAAFklEQVR4nGNgZIACRjCAMGAiIIKBEQABFwAPtF7pNAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":4});
;// CONCATENATED MODULE: ./public/assets/icons/shape/rounded-shape-01.png
/* harmony default export */ const rounded_shape_01 = ({"src":"/_next/static/media/rounded-shape-01.6d5efb14.png","height":904,"width":456,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAAICAMAAADp7a43AAAAD1BMVEXMzMzb29v29vb////R0dGJG0DhAAAACXBIWXMAABcSAAAXEgFnn9JSAAAAHklEQVR4nGNgYGRiZmBgYGACEYwgAgHAXCYGFqASAAGNABehqxc5AAAAAElFTkSuQmCC","blurWidth":4,"blurHeight":8});
;// CONCATENATED MODULE: ./components/Portfolio/Portfolio.jsx







const Portfolio = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "my-10 md:mx-4 min-h-screen relative ",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                src: rounded_shape_01,
                alt: "",
                height: 450,
                className: "absolute -z-10 mt-10 hidden md:block"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                        className: "text-3xl mt-32 my-3 md:text-5xl font-extrabold text-center md:text-left",
                        children: [
                            "Our recent",
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "text-[#FFC700] mx-4",
                                children: "projects"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "border-b-8 border-[#FFC700] mx-auto md:ml-3 w-60 mt-4 mb-20"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "my-10 p-2",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h3", {
                        className: "text-3xl md:text-4xl font-semibold text-center md:text-left",
                        children: [
                            "Website Development for ",
                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                            "Digital Company"
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "md:w-1/2 p-1 md:p-0 my-6",
                        children: "My first thought about art, as a child, was that the artist brings something into the world that did not exist before, and that he does it without destroying something else"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-col md:flex-row gap-0 md:gap-5 p-1 md:p-0 justify-around items-center",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-full md:w-1/2",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: portfolio_01,
                                height: 500,
                                alt: "portfolio-webdevelopment",
                                className: "float-right mb-6 md:mb-0"
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-col gap-8 relative",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: porfolio03,
                                width: 600,
                                height: 500,
                                alt: "portfolio-app-development",
                                className: "shadow-lg"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: porfolio02,
                                width: 600,
                                height: 500,
                                alt: "portfolio-webdevelopment",
                                className: "shadow-md"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const Portfolio_Portfolio = (Portfolio);

;// CONCATENATED MODULE: ./components/Services/ServiceCard01.js



const ServiceCard01 = ({ title , children , icon  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "h-full md:h-72 bg-black p-5 md:p-7 flex flex-col md:flex-row relative mx-2 md:ml-16 items-center my-5",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "bg-[#FFC700] rounded-full h-32 w-32 flex justify-center items-center relative md:absolute left-0 md:-left-16",
                children: icon && /*#__PURE__*/ react_shared_subset.cloneElement(icon, {
                    className: "h-16 w-16 text-white"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: " mx-2 md:ml-20 text-justify",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        className: "text-white text-3xl md:text-[34px] font-semibold md:font-extrabold md:tracking-[1px] mt-5 md:mt-0",
                        children: title
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-white mt-4",
                        children: children
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const Services_ServiceCard01 = (ServiceCard01);

;// CONCATENATED MODULE: ./components/Services/ServiceCard02.js



const ServiceCard02 = ({ title , children , icon  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "h-full md:h-72 bg-black p-5 md:p-7 flex flex-col md:flex-row relative mx-2 md:mr-16 items-center my-5",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "bg-[#FFC700] rounded-full h-32 w-32 flex justify-center items-center relative md:absolute right-0 md:-right-16",
                children: icon && /*#__PURE__*/ react_shared_subset.cloneElement(icon, {
                    className: "h-16 w-16 text-white"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: " mx-2 md:mr-20 text-justify",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        className: "text-white text-3xl md:text-[34px] font-semibold md:font-extrabold md:tracking-[1px] mt-5 md:mt-0",
                        children: title
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-white mt-4",
                        children: children
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const Services_ServiceCard02 = (ServiceCard02);

// EXTERNAL MODULE: ./node_modules/react-icons/fa/index.esm.js
var fa_index_esm = __webpack_require__(7202);
// EXTERNAL MODULE: ./node_modules/react-icons/tb/index.esm.js
var tb_index_esm = __webpack_require__(7305);
;// CONCATENATED MODULE: ./components/Services/Services.js







const Services = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col md:flex-row my-10 md:mx-4",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Services_ServiceCard01, {
                        title: "Software Development",
                        icon: /*#__PURE__*/ jsx_runtime_.jsx(fa_index_esm/* FaDesktop */.lMi, {}),
                        children: "My first thought about art, as a child, was that the artist brings something into the world that did not exist before, and that he does it without destroying something else"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Services_ServiceCard01, {
                        title: "App Development",
                        icon: /*#__PURE__*/ jsx_runtime_.jsx(fa_index_esm/* FaAppStoreIos */.r2Q, {}),
                        children: "My first thought about art, as a child, was that the artist brings something into the world that did not exist before, and that he does it without destroying something else"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                        className: "text-3xl my-3 md:text-5xl font-extrabold text-center md:text-right mx-2 md:mr-16",
                        children: [
                            "We are always ready for",
                            " ",
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "text-[#FFC700]",
                                children: "challenges"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Services_ServiceCard02, {
                        title: "Web Development",
                        icon: /*#__PURE__*/ jsx_runtime_.jsx(tb_index_esm/* TbWorldWww */.rVp, {}),
                        children: "My first thought about art, as a child, was that the artist brings something into the world that did not exist before, and that he does it without destroying something else"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Services_ServiceCard02, {
                        title: "Digital Marketing",
                        icon: /*#__PURE__*/ jsx_runtime_.jsx(fa_index_esm/* FaDigitalOcean */.g9Y, {}),
                        children: "My first thought about art, as a child, was that the artist brings something into the world that did not exist before, and that he does it without destroying something else"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const Services_Services = (Services);

;// CONCATENATED MODULE: ./components/Statistics/StatCard.jsx


const StatCard = ({ numb , details  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "h-60 w-full md:w-80 bg-black hover:text-black flex flex-col items-center justify-center hover:bg-[#ffc600]",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                className: "text-green-500 text-6xl font-semibold ",
                children: numb
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                className: "text-white mt-3 text-3xl",
                children: details
            })
        ]
    });
};
/* harmony default export */ const Statistics_StatCard = (StatCard);

;// CONCATENATED MODULE: ./components/Statistics/Statistics.jsx



const Statistics = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col md:flex-row justify-center gap-1 md:gap-5 mx-1 md:mx-0",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Statistics_StatCard, {
                numb: 124,
                details: "Completed Projects"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Statistics_StatCard, {
                numb: "99%",
                details: "Satisfied Clients"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Statistics_StatCard, {
                numb: 235,
                details: "Success Campaign"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Statistics_StatCard, {
                numb: 1897,
                details: "Cups of Coffee"
            })
        ]
    });
};
/* harmony default export */ const Statistics_Statistics = (Statistics);

// EXTERNAL MODULE: ./node_modules/react-hot-toast/dist/index.mjs
var dist = __webpack_require__(6163);
;// CONCATENATED MODULE: ./app/page.js












function Home() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("main", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(dist/* Toaster */.x7, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Navbar, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Navbar_Hero, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Services_Services, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Portfolio_Portfolio, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(About_About, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Statistics_Statistics, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Blog_Blog, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Our_People_OurPeople, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Contact, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Footer_Footer, {})
        ]
    });
}


/***/ }),

/***/ 2101:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/hero-01.ec71d342.jpg","height":427,"width":640,"blurDataURL":"data:image/jpeg;base64,/9j/2wBDAAoHBwgHBgoICAgLCgoLDhgQDg0NDh0VFhEYIx8lJCIfIiEmKzcvJik0KSEiMEExNDk7Pj4+JS5ESUM8SDc9Pjv/2wBDAQoLCw4NDhwQEBw7KCIoOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozv/wAARCAAFAAgDASIAAhEBAxEB/8QAFQABAQAAAAAAAAAAAAAAAAAAAAb/xAAbEAACAwEBAQAAAAAAAAAAAAABAgADBBEFIf/EABQBAQAAAAAAAAAAAAAAAAAAAAH/xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIRAxEAPwCkbHR4u+q3JUvdLBbC5YkgDg+kxEQL/9k=","blurWidth":8,"blurHeight":5});

/***/ }),

/***/ 94:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/facebook.6dcf26f1.png","height":14,"width":8,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAICAMAAAAGL8UJAAAAIVBMVEX/xAD/xQD/yQBMaXH/xgD/xwD/wwD/xQD+xgD/vwD/1wCAJwauAAAACnRSTlMyrv0AgO9FoNEECWaTdgAAAAlwSFlzAAALEwAACxMBAJqcGAAAAClJREFUeJxjYGbhYmdgYGbkYmBm4GBlYmVhYGViYmJh4GTkYmOGiiORAA/wAKHLb0OFAAAAAElFTkSuQmCC","blurWidth":5,"blurHeight":8});

/***/ }),

/***/ 8859:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/instagram.b728611b.png","height":14,"width":14,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAG1BMVEUAAAAAAAAAAAAAAABMaXEAAAAAAAAAAAAAAABetuXRAAAACXRSTlOzqBw1AAlijCr1OrUxAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAMElEQVR4nDWLyQ0AMAyDsJM03X/iqtcPCSBAgoBI12xBDtQWMlX6gK9iJCd27untCxS5AIs3xmDvAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 2447:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/left.bdce4707.png","height":29,"width":30,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAADFBMVEVMaXEAAAAAAAAAAAAykov8AAAABHRSTlMAFgsmmsHlbgAAAAlwSFlzAAALEwAACxMBAJqcGAAAABxJREFUeJxjYMAEjFCamZEJDBiYGSGAgQkmhQEABJQAH+CeLJcAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 5869:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/linkedin.87133157.png","height":13,"width":13,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAJ1BMVEUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADdEvm1AAAADXRSTlP/wNb1cquHzWDrJDZPkE8SeAAAAAlwSFlzAAALEwAACxMBAJqcGAAAADZJREFUeJw1y0kOADEIxEBDE8j2//dGjDQ+1cU4XwZjNNRQOQsi79kmmHFsJo1tkYJyW+Xi3x8a8QDLVPa3cAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 5167:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/right.3ee3f47a.png","height":29,"width":30,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAGFBMVEVMaXH/xgD/xwD/xgD/wwD/yAD/xwD/yQCiOmDvAAAACHRSTlMAcTxpGTWpzY/D3RcAAAAJcEhZcwAACxMAAAsTAQCanBgAAAAjSURBVHicY2DAAZhZGJhAgJWRjYERBJgZ2aFSjKxQBgtCPQAHdwA4uQrdqQAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 1678:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/team01.9346f4b5.png","height":900,"width":900,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAATlBMVEX///+d6J/O7cWH6Ik/wmJG8m+85Lj6/vzx//U4+Wre/+ac/bjk/uq+/s6t2I9h/4WD8ZAc41XO6clR2XtTzGGb4YoZ/l1p24YpzlOU/a/yqibKAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAPklEQVR4nD3GWw6AIAwEwAVaugXfCur9L2qMifM1wI8Ehzc5xFwMYJqWEDfDOLt6SwV1lePSfoO7nKJeYR88NIEB4xgrgngAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 4005:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/readMore.ea257637.png","height":27,"width":45,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAMAAABPT11nAAAAFVBMVEVMaXH/xgD/zAD/xwD/xwD/xwD/xwCO5DOOAAAAB3RSTlMAUgpcLjfA5vnicQAAAAlwSFlzAAALEwAACxMBAJqcGAAAAB9JREFUeJxjYEAFLCwMjMyMjIyMzGwMTCDAwMoIlwUAA1UAKiWrPmMAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":5});

/***/ }),

/***/ 3637:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/rounded-shape-01.6d5efb14.png","height":904,"width":456,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAAICAMAAADp7a43AAAAD1BMVEXMzMzb29v29vb////R0dGJG0DhAAAACXBIWXMAABcSAAAXEgFnn9JSAAAAHklEQVR4nGNgYGRiZmBgYGACEYwgAgHAXCYGFqASAAGNABehqxc5AAAAAElFTkSuQmCC","blurWidth":4,"blurHeight":8});

/***/ }),

/***/ 4545:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/porfolio02.afe141af.png","height":1281,"width":2342,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAMAAACEE47CAAAAJFBMVEXu7Oro4N/i2tjz6+jSzMj9+PTp5uS3rbPfxLihjp3ey8SXlaRp95bEAAAACXBIWXMAAA7DAAAOwwHHb6hkAAAAJklEQVR4nAXBiQEAMAgCsQO09tl/3yZ4AehSpY6yKKflM2wT9OYDBukAcB+4x6sAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":4});

/***/ }),

/***/ 1086:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/porfolio03.88d18863.png","height":1595,"width":3177,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAMAAACEE47CAAAABlBMVEX19vn6+/wnMr3yAAAACXBIWXMAAA7DAAAOwwHHb6hkAAAAFklEQVR4nGNgZIACRjCAMGAiIIKBEQABFwAPtF7pNAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":4});

/***/ }),

/***/ 726:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/portfolio-01.4bae9d3f.png","height":980,"width":943,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAJ1BMVEX19PPx7+zq3tTu6eTr5N35+fndz8Xl08nEsaW/lYLYvrO5no2dZ1Ziq8ZSAAAACXBIWXMAAA7DAAAOwwHHb6hkAAAANklEQVR4nB3HQRKAQAjEwMyAwKr/f6+FOXUAhSRBBLDIjEz9k/bi2oCqdtjBnPd0VTPP3Lb9ARRIANU/l6drAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 888:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/blog1.a5b33e1b.png","height":163,"width":163,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAe1BMVEWKj46qs7Tc0s5PTky3e2BoZ2Pbk3HEmH4jHBZ9fX7Qz9HUuao3Jx7Dg2eDUTx5WEmjc1uNX06SiYODioagpaLcycTjxLONeGlHRUObkYrRx8G0l4fT09XEtLHXqo6ne2bx3c64cEmTWD5KMCWVXkmEWkyvakpjUU3CrqDN6MyKAAAACXBIWXMAAAsTAAALEwEAmpwYAAAARklEQVR4nAXBhQGAMAADsA7mPtzd/r+QBI7zFhUBrKcsZ2UBacc+71QGGcRMoGvIeKyTNg1O/+wxCAP33pSmZcCnVLrElv13qQPqVyQXSAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 1261:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/blog3.bd92da97.png","height":163,"width":163,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAb1BMVEUGBgd3alne5Oawrq5kSSRqTy1eSTxpWVF4fH2UjIVWQy0xNDbT2N67wsbM0dWjoZ58bWmnp6hMOzCGgXyqnJRtb2+VkoZOMB4hEQdcVFVLUFw2KCOMd25rUzBfZGeLhYN0YFkjJCXJsazJx8Dv7vCMAQoTAAAACXBIWXMAAAsTAAALEwEAmpwYAAAARklEQVR4nAXBBQKAIAAEsEO6RNJu//9GNzhdZOJcwKuazM4YWsitCUPwfk/JRC6wg7xo52fcMZ6D3kbUvu/COgGHUtRZ4AeHLgO93lTqXQAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 2390:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/blog4.b6aaae89.png","height":163,"width":163,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAflBMVEWSZGmldHxpaGV5jYbHnKZvenqWgIihi5KchYBXQEN5WF1KXlyoWWKFd3x3Y2ZrSk+umY+COkXNlp6qqquNbHSHZ3qtmZ3GkJCIZWd9aWmaVGJZTkvWsrePdG7VoZZObmudjo6If4ahdmyzfXfAtrGVdnmRWF6PcYeRenKJTFpeXIgYAAAACXBIWXMAAAsTAAALEwEAmpwYAAAASElEQVR4nAXBBQKAIAAEsEMalLC78/8fdENRCjYSALnkImsHjYrJhK+bg6oNpfIMaNAt9goKaZ9YH6MGmQ9zp15j2tXzvZn7AX0lBA+HNY9rAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 7053:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/blogPhoto.5a1bca16.png","height":422,"width":638,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAMAAABPT11nAAAASFBMVEVidYlESFCkkoVaY3GSiIJygJA4PUhWaoOtpqGTgXCvm4pcSkBxaWWajohVZHl/jZzPsp1hb3yanaTet5nKwrtoZmSNnq3/685iehG6AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAMUlEQVR4nAXBBwIAEAwEsKNoa2///6kErlh3cgrQ+FbqkSCiVnauwCAzfWDAX3Az/AEjDwFyunZwegAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":5});

/***/ }),

/***/ 3610:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/photo1.e60c9991.png","height":220,"width":163,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAICAMAAADtGH4KAAAARVBMVEUOChBEJzJXQFMTFCUhHC44Kj8oGh0mJTwaERUQDxd1TlBTMT1DMzwwLkxYKScdFR4uKTNdPTxmSVtFICZeTV12O0CcV1XGuwweAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAN0lEQVR4nAXBBwLAIAgAsQNRwNHd/v+pTbDlJZOlKlZ4dI7qXF+v1bjfIX4gs7V0zt4ydgiI7QcrzQGTK8NWtAAAAABJRU5ErkJggg==","blurWidth":6,"blurHeight":8});

/***/ }),

/***/ 3899:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/photo2.070ac0cc.png","height":220,"width":163,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAICAMAAADtGH4KAAAAKlBMVEXz8fDj5ub29vb5+/3n7O/s8fTR0dHk2tLx9vje3d3Hw8K7urmlko3Ow74zxIuuAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAL0lEQVR4nDXByQHAIBADsbH3gkD6bzevSPCzMVgKU346TO57YqF5tQrNzkqmW6kPDpUAtRYEgkgAAAAASUVORK5CYII=","blurWidth":6,"blurHeight":8});

/***/ }),

/***/ 7090:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/photo3.5bbebfb0.png","height":421,"width":163,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAMAAAAICAMAAAALMbVOAAAAIVBMVEUDDA4ZHx8mMDI7PDoaIyVqbW5PT001TUsUFxeZnpvGyMcMEQFOAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAI0lEQVR4nAXBAQIAMAQDsVNl5v8PlvDf0ioS0y4mAgmUg+EABzcAXZiZTRAAAAAASUVORK5CYII=","blurWidth":3,"blurHeight":8});

/***/ }),

/***/ 9856:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/photo4.8be2d136.png","height":220,"width":163,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAICAMAAADtGH4KAAAAP1BMVEUpPRxGZTh4jG4/UzFZcz5hdUZUYj4nJB8vTSEmMhvZ2OIxWR4uXRWKmobJztGao5qjrZ6TnXm6vsG3vbmHlWWn6EkDAAAACXBIWXMAAAsTAAALEwEAmpwYAAAANUlEQVR4nAXBiQHAIAgEwVWBA/OYr/9aM0N8ISW3DzLx6w0Sf+axb1ifZwOz1bNoQwWUJOoHKqEBX+H0e24AAAAASUVORK5CYII=","blurWidth":6,"blurHeight":8});

/***/ }),

/***/ 6495:
/***/ (() => {



/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [480], () => (__webpack_exec__(9099)));
module.exports = __webpack_exports__;

})();